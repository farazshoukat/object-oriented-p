/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JETJAWS;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class Membercheck extends JFrame implements ActionListener {
    
    JTextField use;
        JTextField pas;
JLabel lblcheck;
    
    Membercheck()
   { setTitle("JETJAWS");
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       getContentPane().setBackground(Color.white);
       setLayout(null);
       JLabel lblusername= new JLabel("Name id");
       lblusername.setBounds(40, 20,100, 30);
       add(lblusername);
       
       
       JTextField tfusername = new JTextField();
        use=tfusername;
       tfusername.setBounds(150,20,150,30);
       
       add(tfusername);
       JButton addMember = new JButton("Add EMPLOYEE");
        addMember.setBounds(400, 190, 150, 30);
        addMember.setBackground(Color.BLACK);
        addMember.setForeground(Color.white);
        add(addMember);
       
        addMember.addActionListener(this);
       
         JLabel lblpassword= new JLabel("EMPLOYEE id");
       lblpassword.setBounds(40, 70,100, 30);
       add(lblpassword);
                lblcheck  = new JLabel("EMPLOYEE Only");
       lblcheck.setBounds(150, 200,200, 30);
       add(lblcheck);
        JTextField tfpass = new JTextField();
       tfpass.setBounds(150,70,150,30);
       pas =tfpass;
       add(tfpass);
       JButton login=new JButton("Login");
login.setBounds(150,140,150,30);
login.setBackground(Color.BLACK);
login.setForeground(Color.white);
add(login);
       
    
       
       
       
       login.addActionListener(this);
         setSize(600,300);
    setLocation(450,200);
    setVisible(true);
       
   }
    
  
   
    public static void main(String[] args)
    {
        new Membercheck();
    }
   

    @Override
     public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Login")) {
    
            if (verifyMember(use.getText(), pas.getText())) {
               dispose();
                new Reception();
                lblcheck.setText("Login successful");
                
            } else {
                lblcheck.setText("EMPLOYEE Name or ID is not correct");
            }
        } else if (e.getActionCommand().equals("Add EMPLOYEE")) {
  
            addMember();
        }
    }

    private void saveMemberToFile(String name, String id) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("members.txt", true))) {
            writer.write(name + "," + id); 
            writer.newLine();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

 public void addMember()
 {
     
     saveMemberToFile(use.getText(), pas.getText());
     lblcheck.setText("EMPLOYEE added");
 }
  private boolean verifyMember(String name, String id) {
        try (BufferedReader reader = new BufferedReader(new FileReader("members.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2 && parts[0].equals(name) && parts[1].equals(id)) {
                    return true;
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }

        }
       
    
