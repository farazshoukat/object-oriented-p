/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 */

package JETJAWS;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


/**
 *
 * @author HP1
 */
public class Login extends JFrame implements ActionListener {

    JTextField use;
        JTextField pas;

    
    Login()
   {
        setTitle("JETJAWS");
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       getContentPane().setBackground(Color.white);
       setLayout(null);
       JLabel lblusername= new JLabel("Username");
       lblusername.setBounds(40, 20,100, 30);
       add(lblusername);
       
       
       JTextField tfusername = new JTextField();
        use=tfusername;
       tfusername.setBounds(150,20,150,30);
       
       add(tfusername);
       
       
       
         JLabel lblpassword= new JLabel("password");
       lblpassword.setBounds(40, 70,100, 30);
       add(lblpassword);
       
        JTextField tfpass = new JTextField();
       tfpass.setBounds(150,70,150,30);
       pas =tfpass;
       add(tfpass);
       JButton login=new JButton("Login");
login.setBounds(150,140,150,30);
login.setBackground(Color.BLACK);
login.setForeground(Color.white);
add(login);
       
  
       
        ImageIcon i = new ImageIcon(ClassLoader.getSystemResource("icons/second.jpg"));

        
        Image i2 = i.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350, 0, 200, 200);
        add(image);
       login.addActionListener(this);
         setSize(600,300);
    setLocation(450,200);
    setVisible(true);
       
   }
    
    
    
    
    
   
    public static void main(String[] args)
    {
        new Login();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       
        if (use.getText().contains("FARAZ")&& pas.getText().contains("123"))
        {
           
            setVisible(false);
            System.out.println("counter login succesfully");
            new StockDisplay();
        }
        else
        {
            System.out.println("login failed");
        }
    }
}
