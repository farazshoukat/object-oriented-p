package JETJAWS;

import java.awt.Color;
import java.awt.Image;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.io.FileWriter;
import java.io.IOException;
import javax.swing.ImageIcon;


public class OrderMenu extends JFrame implements ActionListener {

JLabel totalLabel;
 

    int pb = 2000;
    int pf = 300;
    int pn = 800;
    int ps = 3000;
    int psh = 200;
    int pi = 90;
    int price;
    int q=100;
    int w=100;
    int e=100;
    int r=100,t=100,y=100;
   
JSpinner js;
    JButton b;
    JSpinner jbu;
    JSpinner jst;
   JSpinner ji;
   JSpinner jnug;
   JSpinner jf;
   JLabel lblstock1;
    JLabel lblstock2;
     JLabel lblstock3;
      JLabel lblstock4;
       JLabel lblstock5;
        JLabel lblstock6;
    OrderMenu() {
       setTitle("APKA APNA STORE( A Project of SHANDAR mobiles and CO. )");
        getContentPane().setBackground(Color.DARK_GRAY);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 700);
        setLocation(300, 50);
        setVisible(true);

        JLabel lblb = new JLabel("BURGERS");
        lblb.setBounds(40, 20, 100, 30);
        lblb.setForeground(Color.red);
        lblb.setBackground(Color.white);
        add(lblb);
         displayStockLabels();
JLabel lblc = new JLabel("Cold Drinks");
        lblc.setForeground(Color.red);
        lblc.setBackground(Color.white);
        lblc.setBounds(40, 70, 100, 30);
        add(lblc);
        
        js = new JSpinner();
        js.setModel(new SpinnerNumberModel(0, 0, 100, 1));
        js.setBounds(150, 20, 150, 30);

       getContentPane().add(js);
        setVisible(true);

         jbu = new JSpinner();
        jbu.setModel(new SpinnerNumberModel(0, 0, 100, 1));
        jbu.setBounds(150, 70, 150, 30);

        getContentPane().add(jbu);
        setVisible(true);
        JLabel lbls = new JLabel("STEAKS");
        lbls.setForeground(Color.red);
        lbls.setBackground(Color.white);
        lbls.setBounds(40, 120, 100, 30);
        add(lbls);
         jst = new JSpinner();
        jst.setModel(new SpinnerNumberModel(0, 0, 100, 1));
        jst.setBounds(150, 120, 150, 30);

        getContentPane().add(jst);
        setVisible(true);
       
        JLabel lblso = new JLabel("SHAKES");
        lblso.setForeground(Color.red);
        lblso.setBackground(Color.white);
        lblso.setBounds(40, 170, 100, 30);
        add(lblso);
         ji = new JSpinner();
        ji.setModel(new SpinnerNumberModel(0, 0, 100, 1));
        ji.setBounds(150, 170, 150, 30);

        getContentPane().add(ji);
        setVisible(true);
        JLabel lblch = new JLabel("FRIES");
        lblch.setForeground(Color.red);
        lblch.setBackground(Color.white);
        lblch.setBounds(40, 220, 100, 30);
        add(lblch);
        jnug = new JSpinner();
        jnug.setModel(new SpinnerNumberModel(0, 0, 100, 1));
        jnug.setBounds(150, 220, 150, 30);

        getContentPane().add(jnug);
        setVisible(true);
        JLabel lblcho = new JLabel("NUGGETS");
        lblcho.setForeground(Color.red);
        lblcho.setBackground(Color.white);
        lblcho.setBounds(40, 270, 100, 30);
        add(lblcho);


         jf = new JSpinner();
        jf.setModel(new SpinnerNumberModel(0, 0, 100, 1));
        jf.setBounds(150, 270, 150, 30);

        getContentPane().add(jf);
        setVisible(true);
        b = new JButton("Bill");
        
        b.setBounds(150, 320, 150, 30);
        b.setBackground(Color.BLACK);
        b.setForeground(Color.white);
        b.addActionListener(this);
        add(b);
           
      totalLabel = new JLabel("Total Price: ");
      totalLabel.setForeground(Color.red);
        totalLabel.setBackground(Color.white);
        totalLabel.setBounds(40, 370, 150, 30);
        add(totalLabel);   
          JButton    back = new JButton("Back");
        back.setBounds(40, 420, 150, 40);
        back.addActionListener(this);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        add(back);
       

    }
private void displayStockLabels() {
        lblstock1 = new JLabel("STOCK " + this.q);
        lblstock1.setForeground(Color.red);
        lblstock1.setBackground(Color.white);
        lblstock1.setBounds(200, 20, 100, 30);
        this.add(lblstock1);

        lblstock2 = new JLabel("STOCK " + this.w);
        lblstock2.setForeground(Color.red);
        lblstock2.setBackground(Color.white);
        lblstock2.setBounds(200, 70, 100, 30);
        this.add(lblstock2);

        lblstock3 = new JLabel("STOCK " + this.e);
        lblstock3.setForeground(Color.red);
        lblstock3.setBackground(Color.white);
        lblstock3.setBounds(200, 120, 100, 30);
        this.add(lblstock3);

        lblstock4 = new JLabel("STOCK " + this.r);
        lblstock4.setForeground(Color.red);
        lblstock4.setBackground(Color.white);
        lblstock4.setBounds(200, 170, 100, 30);
        this.add(lblstock4);

        lblstock5 = new JLabel("STOCK " + this.t);
        lblstock5.setForeground(Color.red);
        lblstock5.setBackground(Color.white);
        lblstock5.setBounds(200, 220, 100, 30);
        this.add(lblstock5);

        lblstock6 = new JLabel("STOCK " + this.y);
        lblstock6.setForeground(Color.red);
        lblstock6.setBackground(Color.white);
        lblstock6.setBounds(200, 270, 100, 30);
        this.add(lblstock6);}
    public static void main(String[] args) {
       new  OrderMenu();
    }
    @Override
    public void actionPerformed(ActionEvent f) {
        String s=f.getActionCommand();
if(s.compareTo("Bill")==0)          
{  int i = (int) js.getValue();
        int d = i * psh;
        int l = (int) jbu.getValue();
        int ba = l * pn;
        int a = (int) jst.getValue();
        int ya = a * pb;
        int ql = (int) ji.getValue();
        int la = ql * pi;
        int wr = (int) jnug.getValue();
        int ia = wr * ps;
        int qa = (int) jf.getValue();
        int kk = qa * pf;
                price=la+ia+ba+d+ya+kk;
     
lblstock1.setText("STOCK " + (this.q -= (int) js.getValue()));
lblstock2.setText("STOCK " + (this.w -= (int) jbu.getValue()));
        lblstock3.setText("STOCK " + (e -= (int) jst.getValue()));
            lblstock4.setText("STOCK " + (r -= (int) ji.getValue()));
            lblstock5.setText("STOCK " + (t -= (int) jnug.getValue()));
            lblstock6.setText("STOCK " + (y -= (int) jf.getValue()));
 checkAvailability();
          totalLabel.setText("YOUR BILL IS : " + price);
        totalLabel.setForeground(Color.red);
        totalLabel.setBackground(Color.white);
              
            try {
                FileWriter writer = new FileWriter("total_price.txt");
                writer.write(String.valueOf(price));
                writer.close();
            } catch (IOException ex) {
                ex.printStackTrace(); 
            }
        } else {
            setVisible(false);
            new Order();
        }

    }
    private void checkAvailability() {
    // Check and update stock labels for availability
    if (this.q < 0) {
        lblstock1.setText("Not Available");
    }
    if (this.w < 0) {
        lblstock2.setText("Not Available");
    }
    if (this.e < 0) {
        lblstock3.setText("Not Available");
    }
    if (this.r < 0) {
        lblstock4.setText("Not Available");
    }
    if (this.t < 0) {
        lblstock5.setText("Not Available");
    }
    if (this.y < 0) {
        lblstock6.setText("Not Available");
    }
     try {
            FileWriter stockWriter = new FileWriter("stock_values.txt");
            stockWriter.write("Stock BURGERS: " + this.q + "\n");
            stockWriter.write("Stock COLD DRINKS: " + this.w + "\n");
            stockWriter.write("Stock STEAKS: " + this.e + "\n");
            stockWriter.write("Stock SHAKES: " + this.r + "\n");
            stockWriter.write("Stock FRIES: " + this.t + "\n");
            stockWriter.write("Stock NUGGETS: " + this.y + "\n");
            stockWriter.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
}
}
