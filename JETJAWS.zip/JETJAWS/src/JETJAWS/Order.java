package JETJAWS;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;

public class Order extends JFrame implements ActionListener {

    Random ran = new Random();
    int number = ran.nextInt(999999);
   
    JLabel lblorderId;
    JButton add, back;

    Order() {
        setTitle("JETJAWS");
        getContentPane().setBackground(Color.DARK_GRAY);
        setLayout(null);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel heading = new JLabel("JETJAWS");
        heading.setBackground(Color.red);
        heading.setForeground(Color.red);
        heading.setBounds(320, 30, 500, 50);
        heading.setFont(new Font("Times New Roman", Font.BOLD, 25));
        add(heading);
        add = new JButton("Add Items to cart");
        add.setBounds(250, 550, 150, 40);
        add.addActionListener(this);
        add.setBackground(Color.BLACK);
        add.setForeground(Color.WHITE);
        add(add);

        back = new JButton("Back");
        back.setBounds(450, 550, 150, 40);
        back.addActionListener(this);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        add(back);

        setSize(900, 700);
        setLocation(300, 50);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
String s=ae.getActionCommand();
if(s.compareTo("Add Items to cart")==0)
{
    setVisible(false);
    new OrderMenu();
}
else
{
    setVisible(false);
    new Reception();
}
    }
    public static void main(String[] args) {
        new Order();
    }
}
