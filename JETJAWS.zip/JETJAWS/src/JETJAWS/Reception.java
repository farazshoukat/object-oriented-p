/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JETJAWS;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/**
 *
 * @author HP1
 */
public class Reception extends JFrame implements ActionListener {
String s;
    Reception()
{  setTitle("JETJAWS");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    getContentPane().setBackground(Color.DARK_GRAY);
        setLayout(null); 
          setSize(1170, 650);
        setLocation(200, 50);
        setVisible(true);
        
        JLabel heading = new JLabel("APKA APNA STORE");
        add(heading);
       
        heading.setBounds(500, 30, 1200, 60);
        heading.setFont(new Font("Times New Roman", Font.PLAIN, 60));
        heading.setForeground(Color.red);
        
        JButton continu=new JButton("Shopping");
continu.setBounds(200,400,200,60);
continu.setBackground(Color.BLACK);

continu.setForeground(Color.white);

continu.addActionListener(this);
s=continu.getText();
add(continu);
        


JButton a=new JButton("Stock Info");
a.setBounds(450,400,200,60);
a.setBackground(Color.BLACK);
a.setForeground(Color.white);
a.addActionListener(this);
s=a.getText();
add(a);


  JButton f=new JButton("ADMIN ONLY");
f.setBounds(325,470,200,60);
f.setBackground(Color.BLACK);
f.setForeground(Color.white);
f.addActionListener(this);
s=f.getText();
add(f);
     
        
}
    @Override
    public void actionPerformed(ActionEvent e) {
String s=e.getActionCommand();
if(s.compareTo("Shopping")==0)
{setVisible(false);
    new Order();
}
else if(s.compareTo("Stock Info")==0)
{
    setVisible(false);
   new inventory();
    
}


else
{
    setVisible(false);
    new Login();
    
}
    } 
    public static void main(String[] args) {
        new Reception();
    }
}
