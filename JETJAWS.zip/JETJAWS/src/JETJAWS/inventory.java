/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JETJAWS;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author HP1
 */
public class inventory extends JFrame implements ActionListener{
    JButton back;
   JLabel lblStock1;
   JLabel lblStock2;
    JLabel lblStock3;
    JLabel lblStock4;
    JLabel lblStock5;
    JLabel lblStock6;
       public static void main(String[] args) {
        new inventory();
    }
    inventory(){
          setTitle("JETJAWS");
              getContentPane().setBackground(Color.DARK_GRAY);
        setLayout(null); 
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  setSize(1170, 650);
        setLocation(200, 50);
        setVisible(true);
        
           lblStock1 = new JLabel("Stock BURGERS: ");
        lblStock2 = new JLabel("Stock Cold Drinks: ");
        lblStock3 = new JLabel("Stock STEAKS: ");
        lblStock4 = new JLabel("Stock SHAKES: ");
        lblStock5 = new JLabel("Stock FRIES: ");
        lblStock6 = new JLabel("Stock NUGGETS: ");
                    lblStock1.setBounds(40, 20, 300, 50);
        lblStock2.setBounds(40, 60, 300, 50);
        lblStock3.setBounds(40, 100, 300, 50);
        lblStock4.setBounds(40, 140, 300, 50);
        lblStock5.setBounds(40, 180, 300, 50);
        lblStock6.setBounds(40, 220, 300, 50);
                lblStock1.setBackground(Color.red);
        lblStock1.setForeground(Color.red);
        lblStock2.setBackground(Color.red);
        lblStock2.setForeground(Color.red);
        lblStock3.setBackground(Color.red);
        lblStock3.setForeground(Color.red);
        lblStock4.setBackground(Color.red);
        lblStock4.setForeground(Color.red);
        lblStock5.setBackground(Color.red);
        lblStock5.setForeground(Color.red);
        lblStock6.setBackground(Color.red);
        lblStock6.setForeground(Color.red);
        add(lblStock1);
        add(lblStock2);
        add(lblStock3);
        add(lblStock4);
        add(lblStock5);
        add(lblStock6);
        display();
    back = new JButton("Back");
        back.setBounds(40, 420, 150, 40);
        back.addActionListener(this);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        add(back);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        setVisible(false);
        new Reception();
    }
    public void display()
    {
       try (BufferedReader reader = new BufferedReader(new FileReader("stock_values.txt"))) {
        String currentLine;
        StringBuilder fileContent = new StringBuilder();

        while ((currentLine = reader.readLine()) != null) {
            fileContent.append(currentLine).append("\n");
        }
        displayUpdatedStockValues(fileContent.toString());
    } catch (IOException | NumberFormatException e) {
       
    }
}
    private void displayUpdatedStockValues(String fileContent) {
    String[] lines = fileContent.split("\n");
    lblStock1.setText(lines[0]);
     lblStock2.setText(lines[1]);
      lblStock3.setText(lines[2]);
    lblStock4.setText(lines[3]);
    lblStock5.setText(lines[4]);
    lblStock6.setText(lines[5]);
}

}
