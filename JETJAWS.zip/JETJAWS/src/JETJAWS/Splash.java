package JETJAWS;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Splash extends JFrame implements ActionListener {
    Splash() {
      
        setTitle("JETJAWS");
        getContentPane().setBackground(Color.DARK_GRAY);
        setLayout(null); 
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel heading = new JLabel("JETJAWS");
        add(heading);
     
       
        heading.setBounds(300, 30, 1200, 60);
        heading.setFont(new Font("Times New Roman", Font.PLAIN, 60));
        heading.setForeground(Color.red);

  
JButton continu=new JButton("Click here");
continu.setBounds(400,400,300,70);
continu.setBackground(Color.BLACK);
continu.setForeground(Color.white);
continu.addActionListener(this);
add(continu);
        setSize(1170, 650);
        setLocation(200, 50);
        setVisible(true);
        
        
        while(true)
        {
            heading.setVisible(false);
            try{
                Thread.sleep(500);
            }catch (Exception e){
            
        } heading.setVisible(true);
           try{
                Thread.sleep(500);
            }catch (Exception e){
            
        }
    }
    }
    public static void main(String[] args) {
       new Splash();
      
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       dispose();
      new Membercheck();
    }
}
