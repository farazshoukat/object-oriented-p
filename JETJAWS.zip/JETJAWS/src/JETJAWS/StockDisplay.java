package JETJAWS;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Pattern;
import javax.swing.JButton;
import javax.swing.JTextField;

public class StockDisplay extends JFrame implements ActionListener {

    JLabel lblStock1;
       JLabel lblStock2;
    JLabel lblStock3;
      JLabel lblStock4;
    JLabel lblStock5;
    JLabel lblStock6;

       JTextField txtUpdateStock1;
    JTextField txtUpdateStock2;
     JTextField txtUpdateStock3;
    JTextField txtUpdateStock4;
     JTextField txtUpdateStock5;
    JTextField txtUpdateStock6;

    JButton btnUpdate;
    public static void main(String[] args) {
        new StockDisplay();
    }
    public StockDisplay() {
        setTitle("Stock Display");
        getContentPane().setBackground(Color.DARK_GRAY);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          setSize(1170, 650);
        setLocation(200, 50);
            setVisible(true);
        lblStock1 = new JLabel("Stock BURGERS: ");
        lblStock2 = new JLabel("Stock Cold Drinks: ");
        lblStock3 = new JLabel("Stock STEAKS: ");
            lblStock4 = new JLabel("Stock SHAKES: ");
        lblStock5 = new JLabel("Stock FRIES: ");
        lblStock6 = new JLabel("Stock NUGGETS: ");
            lblStock1.setBounds(40, 20, 250, 50);
        lblStock2.setBounds(40, 60, 250, 50);
        lblStock3.setBounds(40, 100, 250, 50);
        lblStock4.setBounds(40, 140, 250, 50);
          lblStock5.setBounds(40, 180, 250, 50);
        lblStock6.setBounds(40, 220, 250, 50);
        lblStock1.setBackground(Color.red);
        lblStock1.setForeground(Color.red);
        lblStock2.setBackground(Color.red);
        lblStock2.setForeground(Color.red);
        lblStock3.setBackground(Color.red);
        lblStock3.setForeground(Color.red);
        lblStock4.setBackground(Color.red);
        lblStock4.setForeground(Color.red);
        lblStock5.setBackground(Color.red);
        lblStock5.setForeground(Color.red);
        lblStock6.setBackground(Color.red);
        lblStock6.setForeground(Color.red);
        add(lblStock1);
        add(lblStock2);
        add(lblStock3);
        add(lblStock4);
        add(lblStock5);
        add(lblStock6);
txtUpdateStock1 = new JTextField();
        txtUpdateStock2 = new JTextField();
        txtUpdateStock3 = new JTextField();
          txtUpdateStock4 = new JTextField();
        txtUpdateStock5 = new JTextField();
          txtUpdateStock6 = new JTextField();
        txtUpdateStock1.setBounds(250, 20, 50, 30);
        txtUpdateStock2.setBounds(250, 60, 50, 30);
         txtUpdateStock3.setBounds(250, 100, 50, 30);
        txtUpdateStock4.setBounds(250, 140, 50, 30);
        txtUpdateStock5.setBounds(250, 180, 50, 30);
        txtUpdateStock6.setBounds(250, 220, 50, 30);
        add(txtUpdateStock1);
           add(txtUpdateStock2);
        add(txtUpdateStock3);
         add(txtUpdateStock4);
        add(txtUpdateStock5);
         add(txtUpdateStock6);
            btnUpdate = new JButton("Update Stock");
        btnUpdate.setBounds(150, 260, 150, 30);
        btnUpdate.setBackground(Color.BLACK);
        btnUpdate.setForeground(Color.WHITE);
         btnUpdate.addActionListener(this);
           JButton  back = new JButton("Back");
        back.setBounds(150, 310, 150, 30);
        back.addActionListener(this);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        add(back);
        add(btnUpdate);
        updateStockValues();
    }

private void updateStockValues() {
    try (BufferedReader reader = new BufferedReader(new FileReader("stock_values.txt"))) {
        String currentLine;
        StringBuilder fileContent = new StringBuilder();

        while ((currentLine = reader.readLine()) != null) {
            fileContent.append(currentLine).append("\n");
        }
        fileContent = updateStock(fileContent, "Stock BURGERS", txtUpdateStock1);
        fileContent = updateStock(fileContent, "Stock Cold Drinks", txtUpdateStock2);
        fileContent = updateStock(fileContent, "Stock STEAKS", txtUpdateStock3);
        fileContent = updateStock(fileContent, "Stock SHAKES", txtUpdateStock4);
        fileContent = updateStock(fileContent, "Stock FRIES", txtUpdateStock5);
        fileContent = updateStock(fileContent, "Stock NUGGETS", txtUpdateStock6);
        try (FileWriter writer = new FileWriter("stock_values.txt")) {
            writer.write(fileContent.toString());
        }
        displayUpdatedStockValues(fileContent.toString());
    } catch (IOException | NumberFormatException e) {
       
    }
}
private void displayUpdatedStockValues(String fileContent) {
    String[] lines = fileContent.split("\n");

    lblStock1.setText(lines[0]);
    lblStock2.setText(lines[1]);
    lblStock3.setText(lines[2]);
    lblStock4.setText(lines[3]);
    lblStock5.setText(lines[4]);
    lblStock6.setText(lines[5]);
}

    private StringBuilder updateStock(StringBuilder fileContent, String itemName, JTextField textField) {
    try {
        int updatedValue = Integer.parseInt(textField.getText().trim());
        updatedValue = Math.max(0, Math.min(updatedValue, 100));
        String quotedItemName = Pattern.quote(itemName);
        String updatedLine = itemName + ": " + updatedValue;
        fileContent = new StringBuilder(fileContent.toString().replaceAll(quotedItemName + ": \\d+", updatedLine));
    } catch (NumberFormatException e) {
        
    }

    return fileContent;
}

    @Override
    public void actionPerformed(ActionEvent e) {
        {
    if (e.getSource() == btnUpdate) {
        try {
            updateStockValues();
        } catch (Exception ex) {
     
        }
    }
    else
    {
        dispose();
        new Reception();
    }
}
    }
    
}